import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import OpenAI from "openai";
dotenv.config();

const app = express();
app.use(cors({origin: process.env.ALLOWED_ORIGIN || true}));
app.use(express.json({limit:"1mb"}));

const client = new OpenAI({apiKey:process.env.OPENAI_API_KEY});
app.post("/api/chat", async (req,res) => {
  try {
    if (!process.env.OPENAI_API_KEY) return res.status(503).json({error:"OPENAI_API_KEY fehlt"});
    const messages = Array.isArray(req.body.messages) ? req.body.messages.slice(-20) : [];
    const safeMessages = messages
      .filter(m => ["user","assistant"].includes(m.role) && typeof m.content === "string")
      .map(m => ({role:m.role, content:m.content.slice(0,4000)}));
    const result = await client.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      messages: [
        {role:"system", content:"Du bist J.A.R.V.I.S., ein sachlicher, intelligenter deutschsprachiger KI-Assistent. Begrüße den Benutzer bei passender Gelegenheit mit 'Master'. Antworte präzise und ruhig."},
        ...safeMessages
      ]
    });
    res.json({reply: result.choices?.[0]?.message?.content || "Keine Antwort verfügbar."});
  } catch (error) {
    console.error("Chat API error:", error.message);
    res.status(500).json({error:"KI-Anfrage fehlgeschlagen"});
  }
});
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`JARVIS API läuft auf Port ${port}`));