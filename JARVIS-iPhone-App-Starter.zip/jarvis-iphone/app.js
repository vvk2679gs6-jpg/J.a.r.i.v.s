const API_ENDPOINT = "/api/chat"; // Backend-Endpunkt; siehe server-Ordner.
const conversation = document.getElementById("conversation");
const input = document.getElementById("messageInput");
const form = document.getElementById("chatForm");
const statusText = document.getElementById("systemStatus");
const connectionState = document.getElementById("connectionState");
const listeningLabel = document.getElementById("listeningLabel");
const reactorSub = document.getElementById("reactorSub");
const talkButton = document.getElementById("talkButton");
let history = [];
let recognition = null;
let speaking = false;

function addMessage(role, text) {
  const box = document.createElement("div");
  box.className = `message ${role}`;
  const tag = document.createElement("div");
  tag.className = "message-tag";
  tag.textContent = role === "assistant" ? "J.A.R.V.I.S. • SYSTEM" : "MASTER • INPUT";
  const p = document.createElement("p");
  p.textContent = text;
  box.append(tag, p);
  conversation.appendChild(box);
  conversation.scrollTop = conversation.scrollHeight;
  return p;
}
function setState(state, label) {
  document.body.classList.remove("listening", "speaking");
  if (state) document.body.classList.add(state);
  reactorSub.textContent = label;
  listeningLabel.textContent = label;
}
function speak(text) {
  if (!("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "de-DE";
  utterance.rate = 0.94;
  utterance.pitch = 0.82;
  utterance.onstart = () => { speaking = true; setState("speaking", "SPRICH"); };
  utterance.onend = () => { speaking = false; setState("", "BEREIT"); };
  window.speechSynthesis.speak(utterance);
}
async function sendMessage(text) {
  const clean = text.trim();
  if (!clean) return;
  addMessage("user", clean);
  input.value = "";
  history.push({role:"user", content:clean});
  setState("", "JARVIS DENKT");
  statusText.textContent = "PROCESSING";
  try {
    const response = await fetch(API_ENDPOINT, {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({messages:history})
    });
    if (!response.ok) throw new Error(`Serverfehler ${response.status}`);
    const data = await response.json();
    const answer = data.reply || "Ich konnte keine Antwort erzeugen.";
    history.push({role:"assistant", content:answer});
    addMessage("assistant", answer);
    statusText.textContent = "SYSTEM ONLINE";
    connectionState.textContent = "KI VERBUNDEN";
    speak(answer);
  } catch (err) {
    const message = "Die KI-Verbindung ist noch nicht eingerichtet oder der Server ist nicht erreichbar. Das Interface funktioniert bereits. Für echte KI-Antworten muss der Backend-Server eingerichtet werden.";
    addMessage("assistant", message);
    history.pop();
    statusText.textContent = "LOCAL INTERFACE";
    connectionState.textContent = "BACKEND FEHLT";
    setState("", "BEREIT");
  }
}
form.addEventListener("submit", e => { e.preventDefault(); sendMessage(input.value); });
document.getElementById("voiceBtn").addEventListener("click", startListening);
talkButton.addEventListener("click", startListening);
function startListening() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    addMessage("assistant", "Die Spracherkennung wird von diesem Browser nicht unterstützt. Verwende die Diktierfunktion der iPhone-Tastatur oder teste die App in einem kompatiblen Browser.");
    return;
  }
  if (recognition) recognition.abort();
  recognition = new SpeechRecognition();
  recognition.lang = "de-DE";
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
  recognition.onstart = () => { setState("listening", "ICH HÖRE ZU"); statusText.textContent = "LISTENING"; };
  recognition.onresult = event => {
    const transcript = event.results[0][0].transcript;
    setState("", "AUSWERTUNG");
    sendMessage(transcript);
  };
  recognition.onerror = () => { setState("", "BEREIT"); statusText.textContent = "SYSTEM ONLINE"; };
  recognition.onend = () => { if (!speaking) setState("", "BEREIT"); };
  recognition.start();
}
document.getElementById("clearBtn").addEventListener("click", () => {
  history = [];
  conversation.replaceChildren();
  addMessage("assistant", "Neuer Gesprächskanal initialisiert. Hallo Master, ich bin JARVIS und warte auf deine Befehle.");
  window.speechSynthesis?.cancel();
  setState("", "BEREIT");
});
function updateClock() {
  document.getElementById("clock").textContent = new Intl.DateTimeFormat("de-DE", {hour:"2-digit",minute:"2-digit",second:"2-digit"}).format(new Date());
}
updateClock(); setInterval(updateClock, 1000);
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(()=>{}));
}
