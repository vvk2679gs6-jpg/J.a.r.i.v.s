# J.A.R.V.I.S. – iPhone Web-App

## Enthalten
- Futuristisches HUD-Interface
- Responsive Darstellung für iPhone
- Browser-Spracherkennung (sofern vom Browser unterstützt)
- Deutsche Sprachausgabe über Web Speech API
- PWA-Grundgerüst
- Optionaler OpenAI-Backendserver (API-Nutzung ist kostenpflichtig)

## Wichtige Einschränkung
GitHub Pages kann nur statische Dateien hosten. Es führt `server/server.js` nicht aus.
Für echte KI-Antworten muss der Server separat auf einem Backend-Host laufen. Trage dessen öffentliche Adresse anschließend in `API_ENDPOINT` in `app.js` ein, z. B. `https://DEIN-SERVER.example/api/chat`.
Der API-Schlüssel gehört ausschließlich in die Server-Umgebungsvariablen, niemals in `app.js`.

## Frontend kostenlos testen
Die Dateien `index.html`, `style.css`, `app.js`, `manifest.json` und `sw.js` können als statische Website veröffentlicht werden.
Für GitHub Pages:
1. Repository erstellen und diese Frontend-Dateien ins Repository hochladen.
2. Repository Settings → Pages öffnen.
3. Deploy from a branch → `main` → `/ (root)` wählen.
4. Speichern und die veröffentlichte Adresse in Safari öffnen.
5. Teilen → Zum Home-Bildschirm.

## Backend lokal starten
Voraussetzung: Node.js auf einem Computer.
1. In den Ordner `server` wechseln.
2. `npm install` ausführen.
3. `.env.example` in `.env` kopieren und den API-Schlüssel eintragen.
4. `npm start` ausführen.
5. Für den iPhone-Zugriff muss der Server über eine erreichbare HTTPS-Adresse veröffentlicht werden.

## Sprache
Die Spracherkennung basiert auf der Browser SpeechRecognition API. Die Verfügbarkeit hängt von iOS-/Safari-Version und Berechtigungen ab. Falls sie nicht angeboten wird, kann die iPhone-Diktierfunktion der Tastatur als Ausweichmöglichkeit dienen. Die Sprachausgabe nutzt die im Gerät verfügbaren deutschen Stimmen.

## Datenschutz und Kosten
- Die App sendet Nachrichten an den konfigurierten Backendserver.
- Bei aktiviertem Backend werden Inhalte an die OpenAI API übermittelt.
- API-Nutzung wird separat abgerechnet und ist nicht durch ChatGPT Free enthalten.
- Keine API-Schlüssel im Frontend veröffentlichen.
